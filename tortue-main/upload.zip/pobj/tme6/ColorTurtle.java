package pobj.tme6;

public class ColorTurtle extends Turtle implements IColorTurtle {
	
	private Color color = new Color(0, 0, 0);
	
	public void setColor(Color color) {
		this.color = color;
	}
	
	public Color getColor() {
		return this.color;
	}
	
	public void draw(int x1, int y1, int x2, int y2 ) {
		System.out.println(x1 + " " + y1 + " " + x2 + " " + y2 + " " + color);
	}

}
