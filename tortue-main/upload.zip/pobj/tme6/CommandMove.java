package pobj.tme6;

public class CommandMove implements ICommand {
	
	private int lengh;
	
	public CommandMove(int lengh) {
		this.lengh = lengh;
	}

	@Override
	public void execute(IColorTurtle turtle) {
		turtle.move(this.lengh);
	}

}
