package pobj.tme6;

public class BoundContext implements IContext {
	
	private int MinX = 0;
	private int MinY = 0;
	private int MaxX = 0;
	private int MaxY = 0;

	@Override
	public void drawLine(int x1, int y1, int x2, int y2, Color color) {
		
		if(x2<this.MinX) {
			this.MinX = x2;
		}
		if(x2>this.MaxX) {
			this.MaxX = x2;
		}
		
		if(y2<this.MinY) {
			this.MinY = y2;
		}
		if(y2>this.MaxY) {
			this.MaxY = y2;
		}
		
	}
	
	public int getMinX() {
		return this.MinX;
	}
	
	public int getMinY() {
		return this.MinY;
	}
	
	public int getMaxX() {
		return this.MaxX;
	}
	
	public int getMaxY() {
		return this.MaxY;
	}
	
}
