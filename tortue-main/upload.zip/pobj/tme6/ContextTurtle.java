package pobj.tme6;

public class ContextTurtle extends ColorTurtle implements IColorTurtle {
	
	private IContext ic;
	
	public ContextTurtle(IContext ic) {
		this.ic = ic;
	}
	
	public void draw(int x1, int y1, int x2, int y2 ) {
		this.ic.drawLine(x1, y1, x2, y2, super.getColor());
	}

}
