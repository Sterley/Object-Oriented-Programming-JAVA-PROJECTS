package pobj.tme6;

public interface IColorTurtle extends ITurtle {
	public void setColor(Color color);
}
